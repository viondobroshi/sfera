SFERA WEBSITE — MOBILE OPTIMISED V6

Based on Temporary Public V5. Desktop design is retained.

Mobile improvements:
- iPhone-safe viewport and safe-area support.
- Fixed mobile navigation height/position after removal of the preview bar.
- Accessible hamburger menu with open/close state.
- Larger touch targets and iOS-safe 16px form controls.
- Responsive hero typography and full-width CTAs.
- Shorter mobile hero photography area.
- Fully stacked search and forms.
- More compact mobile section spacing.
- Better property cards and room cards on narrow screens.
- Horizontally scrollable floor filters.
- Full-width room search.
- Phone-friendly PRI gallery and property facts.
- Full-screen room detail modal on mobile.
- Mobile bottom action bar on PRI property page.
- Safe-area-aware footer and bottom CTA.
- Improved 390px-and-below layout.
- Focus-visible accessibility states.
- Reduced risk of horizontal overflow.
