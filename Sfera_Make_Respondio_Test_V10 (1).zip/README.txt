SFERA V10 — WEBSITE → MAKE → RESPOND.IO + EMAIL

This version is simplified for the Growth-plan setup.

FLOW
Sfera website form
→ Vercel server function (/api/request-stay)
→ Make Custom Webhook
→ Respond.io
→ Gmail / email notification

WHY
Respond.io Incoming Webhook requires Advanced.
Your Growth plan supports Make integration, so Make becomes the bridge.

ONLY VERCEL ENVIRONMENT VARIABLE NEEDED
MAKE_WEBHOOK_URL

Set this in:
Vercel → Project → Settings → Environment Variables

Do not put the Make webhook URL in index.html or GitHub.

PAYLOAD SENT TO MAKE
source
property
name
phone
email
room
guests
checkIn
checkOut
message
emailDestination
submittedAt

TEST EMAIL DESTINATION
prishtinacityapartments@gmail.com

DEPLOY
Deploy this folder:
index.html
vercel.json
api/request-stay.js

TEST
1. In Make click Run once on the Custom Webhook scenario.
2. Submit a test stay request from the live Sfera website.
3. Make should capture the fields automatically.
4. Then add Respond.io and Gmail modules.
